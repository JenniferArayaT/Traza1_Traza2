package Trazas.Traza1.entities;

import lombok.Getter;
import lombok.experimental.SuperBuilder;


@Getter
@SuperBuilder
public class Pais extends EntidadBaseTraza1 {

}
